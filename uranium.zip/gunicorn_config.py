command = '/home/ubuntu/env/bin/gunicorn '
pythonpath = '/home/ubuntu/uranium'
bind = '91.184.240.223:8000'
workers = 3